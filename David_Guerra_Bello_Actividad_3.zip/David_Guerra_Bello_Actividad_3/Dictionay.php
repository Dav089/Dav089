<?php
    $dictionary = array();

    $contador = readline("Por favor, introduzca el numero por aqui");

    for($x=0; $x<$contador; $x++)
    {
        $termino = readline("Su palabra especial");
        $definicion = readline("La definicion:");
        $dictionary[$termino] = $definicion; 
    }

    
    
        print_r($dictionary);
    
?>
