<?php
    $information = array();
    for($x=0; $x<1; $x++)
    {
        $z = readline("Nombre del almacenamiento: ");
        $information['Nombre'] = readline("Nombre: ");
        $information['Primer Apellido']  = readline("Primer apellido: ");
        $information['Segundo Apellido']  = readline("Segundo apellido: ");
        $information['Nacimiento']  = readline("Fecha de nacimiento: ");
        $information['Dirección']  = readline("Dirección: ");
        $information['Correo']  = readline("Correo: ");
        $information['Teléfono']  = readline("Teléfono: ");
        
    }
    print_r($information);
?>