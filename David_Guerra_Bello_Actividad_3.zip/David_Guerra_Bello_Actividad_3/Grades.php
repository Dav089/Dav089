<?php
   
    $student_one = array("Maths"=>95, 
    "Physics"=>90,
    "Chemistry"=>96, 
    "English"=>93,
    "ICT"=>98);

    $student_two["Maths"] = 95;
    $student_two["Physics"] = 90;
    $student_two["Chemistry"] = 96;
    $student_two["English"] = 93;
    $student_two["ICT"] = 98;



    $student_three["Maths"] = 65;
    $student_three["Physics"] = 60;
    $student_three["Chemistry"] = 66;
    $student_three["English"] = 63;
    $student_three["ICT"] = 68;

    $student_four["Maths"] = 55;
    $student_four["Physics"] = 50;
    $student_four["Chemistry"] = 56;
    $student_four["English"] = 53;
    $student_four["ICT"] = 58;

    $list = array($student_one, $student_two, $student_three, $student_four);
    for ($x=0; $x<1; $x++){
        print_r($list);
    }

    $media["Alumno 1"] = array($student_one);
    $media["Alumno 2"] = array($student_two);
    $media["Alumno 3"] = array($student_three);
    $media["Alumno 4"] = array($student_four);

    for($i=0; $i<1; $i++){
        $media["Alumno 1"] = array_sum($student_one) / count($student_one);
        $media["Alumno 2"] = array_sum($student_two) / count($student_two);
        $media["Alumno 3"] = array_sum($student_three) / count($student_three);
        $media["Alumno 4"] = array_sum($student_four) / count($student_four);
        print_r($media);
    }
?>
