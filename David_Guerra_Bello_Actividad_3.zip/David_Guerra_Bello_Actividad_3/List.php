<?php
    $pokamion = array();

    $list = readline ("Por favor, introduzca el número del Pokémon: ");
    for ($x = 0; $x<$list; $x++)
    {
        $pokamion[$x] = readline ("Nombre del susodicho: ");
    }
    for ($x = 0; $x<$list; $x++)
    {
        print_r($pokamion[$x]. "\n");
    }
?>