<?php
    $pokemons =
    Array("Bulbasaur","Ivysaur","Venusaur","Charmander","Charmeleon","Ch
    arizard","Squirtle","Wartortle","Blastoise","Caterpie","Metapod","Bu
    tterfree","Weedle","Kakuna","Beedrill","Pidgey","Pidgeotto","Pidgeot
    ","Rattata","Raticate","Spearow","Fearow","Ekans","Arbok","Pikachu",
    "Raichu","Sandshrew","Sandslash","Nidoran","Nidorina","Nidoqueen","N
    idoran","Nidorino","Nidoking","Clefairy","Clefable","Vulpix","Nineta
    les","Jigglypuff","Wigglytuff","Zubat","Golbat","Oddish","Gloom","Vi
    leplume","Paras","Parasect","Venonat","Venomoth","Diglett","Dugtrio"
    ,"Meowth","Persian","Psyduck","Golduck","Mankey","Primeape","Growlit
    he","Arcanine","Poliwag","Poliwhirl","Poliwrath","Abra","Kadabra","A
    lakazam","Machop","Machoke","Machamp","Bellsprout","Weepinbell","Vic
    treebel","Tentacool","Tentacruel","Geodude","Graveler","Golem","Pony
    ta","Rapidash","Slowpoke","Slowbro","Magnemite","Magneton","Farfetch
    'd","Doduo","Dodrio","Seel","Dewgong","Grimer","Muk","Shellder","Clo
    yster","Gastly","Haunter","Gengar","Onix","Drowzee","Hypno","Krabby"
    ,"Kingler","Voltorb","Electrode","Exeggcute","Exeggutor","Cubone","M
    arowak","Hitmonlee","Hitmonchan","Lickitung","Koffing","Weezing","Rh
    yhorn","Rhydon","Chansey","Tangela","Kangaskhan","Horsea","Seadra","
    Goldeen","Seaking","Staryu","Starmie","Mr.
    Mime","Scyther","Jynx","Electabuzz","Magmar","Pinsir","Tauros","Magi
    karp","Gyarados","Lapras","Ditto","Eevee","Vaporeon","Jolteon","Flar
    eon","Porygon","Omanyte","Omastar","Kabuto","Kabutops","Aerodactyl",
    "Snorlax","Articuno","Zapdos","Moltres","Dratini","Dragonair","Drago
    nite","Mewtwo","Mew");

    $search = readline("Nombre del Pokemon: ");
    $victory = false;
    for($i=0; $i < count($pokemons); $i++){
        if($search == $pokemons[$i]){

            echo "ID del Pokemon: ".($i+1);
        }
    } 

    if (!$victory){
        echo "Si no te sabes las generaciones, no se que haces aqui.";
    }
?>